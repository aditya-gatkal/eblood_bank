<?php
echo hash('sha256', 'aditya123');
?>
